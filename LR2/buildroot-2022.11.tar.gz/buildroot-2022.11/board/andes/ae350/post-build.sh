#!/bin/sh
cp $BINARIES_DIR/Image $TARGET_DIR/boot
cp $BINARIES_DIR/ae350.dtb $TARGET_DIR/boot
